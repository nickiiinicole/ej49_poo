class Gamin_exception(Exception):
    def __init__(self, *args):
        super().__init__(*args)
        